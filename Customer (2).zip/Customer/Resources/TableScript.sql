CREATE TABLE Customer(
customerId NUMBER PRIMARY KEY,
customerName VARCHAR2(20),
age NUMBER(3),
phoneNumber NUMBER(10),
productInterested VARCHAR2(20),
regDate DATE);

CREATE SEQUENCE customer_id_seq
START WITH 1000;