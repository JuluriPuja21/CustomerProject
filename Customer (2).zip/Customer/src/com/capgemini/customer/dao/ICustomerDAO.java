package com.capgemini.customer.dao;

import com.capgemini.customer.bean.CustomerBean;
import com.capgemini.customer.exception.CustomerException;

public interface ICustomerDAO {
	

	public String addCustomerDetails(CustomerBean customer)throws CustomerException;

}
