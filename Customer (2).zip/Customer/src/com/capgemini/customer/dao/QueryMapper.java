package com.capgemini.customer.dao;

public interface QueryMapper {
	
	
	public static final String INSERT_QUERY="INSERT INTO Customer VALUES(CustomerId_seq.NEXTVAL,?,?,?,?,SYSDATE)";
	public static final String CUSTOMER_ID_QUERY_SEQUENCE="SELECT CustomerId_seq.CURRVAL FROM DUAL";
	
	}
