package com.capgemini.customer.test;   

import static org.junit.Assert.*;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.customer.bean.CustomerBean;
import com.capgemini.customer.dao.CustomerDAO;
import com.capgemini.customer.exception.CustomerException;


public class CustomerDaoTest {

    static CustomerDAO dao;
    static CustomerBean customer;

    @BeforeClass
    public static void initialize() {
        dao = new CustomerDAO();
        customer = new CustomerBean();
    }

    @Test
    public void testAddCustomerDetails() throws CustomerException {

        assertNotNull(dao.addCustomerDetails(customer));
    }
    
    /************************************
     * Test case for addCustomerDetails()
     * 
     ************************************/

    @Ignore
    @Test
    public void testAddCustomerDetails1() throws CustomerException {
        assertEquals(1001, dao.addCustomerDetails(customer));
    }

    /************************************
     * Test case for addCustomerDetails()
     * 
     ************************************/

    @Test
    public void testAddCustomerDetails2() throws CustomerException {
        
        customer.setCustomerName("puja");
        customer.setAge("22");
        customer.setPhoneNumber("9000342237");
        customer.setProductInterested("apple");
        assertTrue("Data Inserted successfully",
                Integer.parseInt(dao.addCustomerDetails(customer)) > 1000);

    }
}