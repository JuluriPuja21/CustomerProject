package com.capgemini.customer.bean;

import java.util.Date;

public class CustomerBean {
private  String customerName;
private String customerId;
private String age;
private String phoneNumber;
private String productInterested;
private Date regDate;
public Date getRegDate() {
	return regDate;
}
public void setRegDate(Date regDate) {
	this.regDate = regDate;
}
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public String getAge() {
	return age;
}
public void setAge(String age) {
	this.age = age;
	
}
public String getPhoneNumber() {
	return phoneNumber;
}
public void setPhoneNumber(String phoneNumber) {
	this.phoneNumber = phoneNumber;
}
public String getProductInterested() {
	return productInterested;
}
public void setProductInterested(String productInterested) {
	this.productInterested = productInterested;
}
public String getCustomerId() {
	return customerId;
}
public void setCustomerId(String customerId) {
	this.customerId = customerId;
}

public String toString()
{
	StringBuilder sb = new StringBuilder();
	sb.append("Printing Customer Details \n");
	sb.append("Customer Name: " +customerName +"\n");
	sb.append("Customer age: "+ age +"\n");
	sb.append("Phone Number: "+ phoneNumber +"\n");
	sb.append("Product intrested: "+ productInterested +"\n");
	sb.append("Registration Date: "+ regDate);
	return sb.toString();
}




}
